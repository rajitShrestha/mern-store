const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const booksRoute = require('../routes/booksRoute.js');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5555; // Use port from environment variable or default to 5555
const mongoDBURL = process.env.MONGODB_URL; // MongoDB URL from environment variable

// Middleware for parsing request body
app.use(express.json());

// Middleware for handling CORS POLICY
app.use(cors());

// Serve static files from the frontend directory
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Define route for serving the frontend index.html file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

app.use('/books', booksRoute);

mongoose
  .connect(mongoDBURL, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('App connected to database');
    app.listen(PORT, () => {
      console.log(`App is listening to port: ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(error);
  });
