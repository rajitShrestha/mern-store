const PORT = 5555;

const mongoDBURL =
  'mongodb+srv://rajitshrestha646:snhfuGHLUsbVP4xJ@cluster0.e5tlk4i.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
module.exports = {
  PORT,
  mongoDBURL
};