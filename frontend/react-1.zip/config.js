// config.js
// const API_BASE_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5555';

const API_BASE_URL = 'http://192.168.33.10:5555';

export default API_BASE_URL;
